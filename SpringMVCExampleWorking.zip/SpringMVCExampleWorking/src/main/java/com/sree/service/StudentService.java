package com.sree.service;

import com.sree.model.Student;

public interface StudentService {
	public void addStudent(Student student);
}
