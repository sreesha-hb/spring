package com.sree.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="students1")
public class Student {
	@Id
	@Column(name="studId")
	private int sid;
	@Column(name="studName")
	private String sName;
	@Column(name="studClass")
	private String sClass;
	@Column(name="studEvent")
	private String sEvent;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsClass() {
		return sClass;
	}
	public void setsClass(String sClass) {
		this.sClass = sClass;
	}
	public String getsEvent() {
		return sEvent;
	}
	public void setsEvent(String sEvent) {
		this.sEvent = sEvent;
	}
	
	
}
