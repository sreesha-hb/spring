package com.sree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sree.bean.StudentBean;
import com.sree.model.Student;
import com.sree.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("home");
	}
	
	@RequestMapping(value="/register", method = RequestMethod.GET)
	public ModelAndView addStudent(@ModelAttribute("command") StudentBean studentBean, BindingResult result) {
		return new ModelAndView("registration");
	}
	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public ModelAndView saveStudent(@ModelAttribute("command") StudentBean studentBean, BindingResult result) {
		Student student = prepareData(studentBean);
		studentService.addStudent(student);
		return new ModelAndView ("redirect:/register.html");
	}
	
	private Student prepareData(StudentBean studentBean) {
		Student student = new Student();
		student.setSid(studentBean.getId());
		student.setsName(studentBean.getName());
		student.setsClass(studentBean.getSclass());
		student.setsEvent(studentBean.getEvent());
		return student;
	}
}
