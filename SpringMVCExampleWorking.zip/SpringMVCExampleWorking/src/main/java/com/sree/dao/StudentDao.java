package com.sree.dao;

import com.sree.model.Student;

public interface StudentDao {
	public void addStudent(Student student);
}
