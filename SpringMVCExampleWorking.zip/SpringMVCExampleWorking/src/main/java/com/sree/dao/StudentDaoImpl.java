package com.sree.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sree.model.Student;

@Repository("studentDao")
public class StudentDaoImpl implements StudentDao {
	@Autowired
	private SessionFactory sf;

	
	public void addStudent(Student student) {
		sf.getCurrentSession().save(student);
	}
	
}
